- Instructions are hopefully on download page 
 
 - made by KNIZE_1007