- Instructions are hopefully on the download page

- Made by KNIZE_1007